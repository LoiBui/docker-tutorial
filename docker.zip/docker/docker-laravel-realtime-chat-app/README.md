# Introduction
This project demo how to Dockerize Laravel realtime chat app
# Features
- Realtime chat app using Private and Presence channel in Laravel
- Schedule task
- Laravel Horizon
- Laravel Worker